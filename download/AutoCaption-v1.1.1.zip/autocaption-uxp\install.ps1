﻿# ============================================================
#  AutoCaption - Premiere Pro 자동 자막 플러그인 설치
#  실행: install.bat 더블클릭 (또는 이 파일을 PowerShell로 실행)
#  검증용: powershell -File install.ps1 -SkipTools -SkipPlugin
# ============================================================
param(
    [string]$DestRoot = (Join-Path $env:LOCALAPPDATA "AutoCaption"),
    [switch]$SkipTools,
    [switch]$SkipPlugin,
    [switch]$SkipAutoStart
)
$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=== AutoCaption 설치 시작 ===" -ForegroundColor Cyan
Write-Host "    사용 조건: Windows 10/11, Premiere Pro 25.6 이상"
Write-Host ""

# 설치하지 못한 구성요소 목록 - 마지막에 "설치 완료"인지 "덜 끝남"인지 정직하게 알려주는 데 쓴다.
$script:missingTools = @()

# ---- Premiere Pro 버전 확인 (경고만, 설치는 계속) ----------------
# 버전을 잘못 읽는 경우도 있을 수 있어서 설치를 막지는 않는다.
$minPremiere = [version]"25.6"
$foundPremiere = @()
foreach ($pf in @($env:ProgramFiles, ${env:ProgramW6432}) | Where-Object { $_ } | Select-Object -Unique) {
    Get-ChildItem -LiteralPath (Join-Path $pf "Adobe") -Directory -Filter "Adobe Premiere Pro*" -ErrorAction SilentlyContinue | ForEach-Object {
        $exe = Join-Path $_.FullName "Adobe Premiere Pro.exe"
        if (Test-Path -LiteralPath $exe) {
            $pv = (Get-Item -LiteralPath $exe).VersionInfo.ProductVersion
            if ($pv -match '^(\d+)\.(\d+)') { $foundPremiere += [version]("{0}.{1}" -f $Matches[1], $Matches[2]) }
        }
    }
}
if ($foundPremiere.Count -eq 0) {
    Write-Host "  ! Premiere Pro를 찾지 못했습니다. 설치는 계속하지만, Premiere Pro 25.6 이상이 있어야 패널을 쓸 수 있어요." -ForegroundColor Yellow
} else {
    $bestPremiere = ($foundPremiere | Sort-Object -Descending)[0]
    if ($bestPremiere -lt $minPremiere) {
        Write-Host "  ! 설치된 Premiere Pro가 $bestPremiere 버전입니다. 25.6 이상이 아니면 패널이 보이지 않을 수 있어요." -ForegroundColor Yellow
        Write-Host "    (Creative Cloud 앱에서 Premiere Pro를 업데이트한 뒤 사용해 주세요. 설치는 계속합니다.)" -ForegroundColor Yellow
    } else {
        Write-Host "  - Premiere Pro $bestPremiere 확인" -ForegroundColor Green
    }
}
Write-Host ""

# ---- 0. 원본 폴더 확인 ----------------------------------------
$here = $PSScriptRoot
if (-not $here) { $here = Split-Path -Parent $MyInvocation.MyCommand.Path }
$srcServer = Join-Path $here "server"
$srcPlugin = Join-Path $here "plugin"
if (-not (Test-Path -LiteralPath $srcServer) -or -not (Test-Path -LiteralPath $srcPlugin)) {
    Write-Host "오류: install.bat 옆에 server, plugin 폴더가 없습니다." -ForegroundColor Red
    Write-Host "압축을 통째로 풀지 않았다면, 먼저 압축을 전부 풀고 다시 실행하세요."
    exit 1
}

# ---- 1. 서버/플러그인 파일 복사 --------------------------------
New-Item -ItemType Directory -Force $DestRoot | Out-Null

function Test-Junction($p) {
    $item = Get-Item -Force -LiteralPath $p
    return [bool]($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint)
}

$dstServer = Join-Path $DestRoot "server"
$dstPlugin = Join-Path $DestRoot "plugin"
# 재설치/업데이트일 때, 이전에 켜둔 서버가 파일을 잠그고 있으면 삭제가 막힌다.
# node.exe만 죽이면 안 된다 - run-server-hidden.vbs가 띄운 wscript.exe와,
# 그 wscript가 실행한 start-server.bat을 돌리는 cmd.exe가 그 폴더를
# "현재 작업 폴더"로 잡고 있어서, node.exe를 꺼도 cmd.exe가 폴더 자체를
# 계속 잠그고 있는 경우가 있었다 (Remove-Item이 계속 실패하던 원인).
# 그래서 node.exe/cmd.exe/wscript.exe 중 커맨드라인에 AutoCaption 서버
# 관련 흔적이 있는 건 전부 찾아서 끈다.
function Stop-AutoCaptionServerProcesses {
    try {
        $procs = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object {
                $_.ProcessId -ne $PID -and
                ($_.Name -eq "node.exe" -or $_.Name -eq "cmd.exe" -or $_.Name -eq "wscript.exe" -or $_.Name -eq "powershell.exe") -and
                $_.CommandLine -and
                ($_.CommandLine -like "*AutoCaption*server.js*" -or
                 $_.CommandLine -like "*AutoCaption*start-server.bat*" -or
                 $_.CommandLine -like "*AutoCaption*start-server-hidden.ps1*" -or
                 $_.CommandLine -like "*run-server-hidden.vbs*")
            }
        foreach ($p in $procs) {
            Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
        }
        return $procs.Count
    } catch {
        return 0
    }
}

$killed = Stop-AutoCaptionServerProcesses
if ($killed -gt 0) {
    Write-Host "  - 실행 중이던 이전 서버를 종료했습니다 ($killed 개 프로세스)" -ForegroundColor DarkGray
    Start-Sleep -Milliseconds 800
}

foreach ($pair in @(@{src=$srcServer; dst=$dstServer}, @{src=$srcPlugin; dst=$dstPlugin})) {
    if (Test-Path -LiteralPath $pair.dst) {
        if (Test-Junction $pair.dst) {
            Write-Host "오류: $($pair.dst) 는 개발용 정션입니다. 보호를 위해 중단합니다." -ForegroundColor Red
            exit 1
        }
        try {
            Remove-Item -Recurse -Force -LiteralPath $pair.dst -ErrorAction Stop
        } catch {
            Write-Host "  - $($pair.dst) 삭제 실패, 서버 종료를 한 번 더 시도합니다..." -ForegroundColor Yellow
            Stop-AutoCaptionServerProcesses | Out-Null
            Start-Sleep -Seconds 1
            try {
                Remove-Item -Recurse -Force -LiteralPath $pair.dst -ErrorAction Stop
            } catch {
                # 그래도 안 되면 1초 더 기다렸다가 마지막으로 한 번 더 (핸들 해제 지연 대비)
                Stop-AutoCaptionServerProcesses | Out-Null
                Start-Sleep -Seconds 2
                try {
                    Remove-Item -Recurse -Force -LiteralPath $pair.dst -ErrorAction Stop
                } catch {
                    Write-Host "오류: $($pair.dst) 를 지울 수 없습니다." -ForegroundColor Red
                    Write-Host "작업 관리자에서 node.exe / cmd.exe / wscript.exe를 찾아 직접 끝내고 install.bat을 다시 실행해주세요." -ForegroundColor Red
                    exit 1
                }
            }
        }
    }
    Copy-Item -Recurse -LiteralPath $pair.src -Destination $pair.dst
}
if (-not (Test-Path -LiteralPath (Join-Path $dstServer "server.js"))) {
    Write-Host "오류: 설치 검증 실패 - $dstServer 에 파일이 복사되지 않았습니다 (백신이 막았는지 확인)." -ForegroundColor Red
    exit 1
}
Write-Host "[1/5] 서버/플러그인 파일 복사 완료 -> $DestRoot" -ForegroundColor Green

# ---- 2. 필수 구성요소 (Node.js / Python / ffmpeg) --------------
if ($SkipTools) {
    Write-Host "[2/5] 구성요소 설치 건너뜀 (-SkipTools)"
} else {
    Write-Host "[2/5] 필수 구성요소 확인 중... (처음이면 몇 분 걸릴 수 있어요)"
    $hasWinget = $null -ne (Get-Command winget -ErrorAction SilentlyContinue)

    function Update-SessionPath {
        # winget으로 설치한 직후에는 이 창의 PATH에 새 프로그램이 아직 없다.
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
            [System.Environment]::GetEnvironmentVariable("Path", "User") + ";" +
            (Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links")
    }

    # "명령이 있는지"가 아니라 "실제로 실행되는지"로 판단한다.
    # 새 Windows에는 실행하면 Microsoft Store만 여는 가짜 python.exe(WindowsApps)가 있어서,
    # Get-Command만 보면 Python이 없는데도 "이미 설치됨"으로 착각했다.
    function Test-Tool($cmd) {
        $c = Get-Command $cmd -ErrorAction SilentlyContinue
        if (-not $c) { return $false }
        if ($c.Source -and $c.Source -like "*\WindowsApps\*" -and $cmd -eq "python") { return $false }
        $verArg = if ($cmd -eq "ffmpeg") { "-version" } else { "--version" }
        $ErrorActionPreference = "Continue"  # 이 함수 안에서만 (stderr 출력만으로 실패 처리되지 않게)
        try {
            $outText = (& $cmd $verArg 2>&1 | Out-String)
            if ($LASTEXITCODE -ne 0) { return $false }
            if ($cmd -eq "python") { return ($outText -match "Python 3\.") }
            return $true
        } catch { return $false }
    }

    function Ensure-Tool($cmd, $wingetId, $name, $url) {
        if (Test-Tool $cmd) {
            Write-Host "  - ${name}: 이미 설치됨" -ForegroundColor Green
            return
        }
        if (-not $hasWinget) {
            Write-Host "  - ${name}: 없음 (winget이 없어 자동 설치 불가)" -ForegroundColor Yellow
            $script:missingTools += [pscustomobject]@{ name = $name; url = $url }
            return
        }
        Write-Host "  - ${name} 설치 중... (몇 분 걸릴 수 있어요)"
        $code = -1
        try {
            # --source winget: 지정하지 않으면 Microsoft Store 출처(msstore)까지 함께 검색하는데, Store가
            # 막혀 있거나 준비가 안 된 PC(회사 PC, Windows 샌드박스로 확인)에서는 그쪽이
            # 0x8A15003B(REST API internal error)로 실패하면서 설치 전체가 실패했다.
            winget install --id $wingetId -e --source winget --accept-source-agreements --accept-package-agreements --silent | Out-Null
            $code = $LASTEXITCODE
        } catch { }
        Update-SessionPath
        # winget은 실패해도 오류를 "던지지" 않아서, 예전에는 실패해도 "설치 완료"라고 나왔다.
        # 설치 후 실제로 실행되는지 다시 확인해서 판단한다.
        if (Test-Tool $cmd) {
            Write-Host "  - ${name}: 설치 완료" -ForegroundColor Green
        } else {
            Write-Host "  - ${name}: 설치 실패 (winget 결과 코드 $code)" -ForegroundColor Red
            $script:missingTools += [pscustomobject]@{ name = $name; url = $url }
        }
    }

    Update-SessionPath
    Ensure-Tool "node"   "OpenJS.NodeJS.LTS"  "Node.js (로컬 서버 실행)"      "https://nodejs.org/ko/download"
    Ensure-Tool "ffmpeg" "Gyan.FFmpeg"        "ffmpeg (오디오/영상 처리)"     "https://www.gyan.dev/ffmpeg/builds/"
    Ensure-Tool "python" "Python.Python.3.12" "Python (Whisper 음성 인식)"   "https://www.python.org/downloads/windows/"

    # Microsoft Visual C++ 런타임: faster-whisper가 쓰는 ctranslate2.dll이 필요로 한다.
    # 새 Windows에는 기본으로 없어서(Windows 샌드박스로 확인), 없으면 faster-whisper는 설치돼도
    # "Could not find module ...ctranslate2.dll (or one of its dependencies)"로 실행되지 않았다.
    $vcName = "Microsoft Visual C++ 런타임 (음성 인식 엔진에 필요)"
    $vcUrl = "https://aka.ms/vs/17/release/vc_redist.x64.exe"
    function Test-VcRuntime {
        foreach ($k in @("HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x64")) {
            $v = Get-ItemProperty -Path $k -ErrorAction SilentlyContinue
            if ($v -and $v.Installed -eq 1) { return $true }
        }
        return (Test-Path -LiteralPath (Join-Path $env:SystemRoot "System32\msvcp140.dll")) -and
               (Test-Path -LiteralPath (Join-Path $env:SystemRoot "System32\vcruntime140_1.dll"))
    }
    if (Test-VcRuntime) {
        Write-Host "  - ${vcName}: 이미 설치됨" -ForegroundColor Green
    } elseif ($hasWinget) {
        Write-Host "  - ${vcName} 설치 중..."
        $code = -1
        try {
            winget install --id Microsoft.VCRedist.2015+.x64 -e --source winget --accept-source-agreements --accept-package-agreements --silent | Out-Null
            $code = $LASTEXITCODE
        } catch { }
        if (Test-VcRuntime) { Write-Host "  - ${vcName}: 설치 완료" -ForegroundColor Green }
        else {
            Write-Host "  - ${vcName}: 설치 실패 (winget 결과 코드 $code)" -ForegroundColor Red
            $script:missingTools += [pscustomobject]@{ name = $vcName; url = $vcUrl }
        }
    } else {
        Write-Host "  - ${vcName}: 없음 (winget이 없어 자동 설치 불가)" -ForegroundColor Yellow
        $script:missingTools += [pscustomobject]@{ name = $vcName; url = $vcUrl }
    }

    if (Test-Tool "python") {
        Write-Host "  - faster-whisper(pip) 설치 중... (처음엔 몇 분 걸릴 수 있어요)"
        # pip은 경고를 stderr로 쓰는데, Windows PowerShell 5.1에서는 그것만으로 "오류"가 되어
        # 멀쩡히 설치돼도 실패로 보이거나 반대가 될 수 있다. 결과는 import가 되는지로 판단한다.
        $prevEap = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        try {
            & python -m pip install --upgrade pip --quiet 2>&1 | Out-Null
            & python -m pip install faster-whisper --quiet 2>&1 | Out-Null
            $fwErr = (& python -c "import faster_whisper" 2>&1 | Out-String)
            $fwOk = ($LASTEXITCODE -eq 0)
            & python "$dstServer\pipeline\patch_av_compat.py" 2>&1 | Out-Host
        } catch { $fwOk = $false }
        $ErrorActionPreference = $prevEap
        if ($fwOk) {
            Write-Host "  - faster-whisper: 설치 완료" -ForegroundColor Green
        } else {
            # 원인을 짐작해서 쓰지 않고 실제 오류의 마지막 줄을 보여준다 (사용자가 캡처해 보내기 쉽게).
            $lastLine = (($fwErr -split "`r?`n") | Where-Object { $_.Trim() } | Select-Object -Last 1)
            Write-Host "  - faster-whisper(음성 인식 엔진): 실행 확인 실패" -ForegroundColor Red
            if ($lastLine) { Write-Host "    오류: $lastLine" -ForegroundColor Red }
            if ($fwErr -match "ctranslate2|DLL|dependencies") {
                Write-Host "    -> Visual C++ 런타임이 없거나 손상된 경우가 많습니다: $vcUrl 설치 후 PC 재시작" -ForegroundColor Yellow
            } else {
                Write-Host "    -> 인터넷 연결을 확인하고 install.bat을 다시 실행해 주세요" -ForegroundColor Yellow
            }
            $script:missingTools += [pscustomobject]@{ name = "faster-whisper (음성 인식 엔진) - 위 오류 참고"; url = "" }
        }
    } else {
        Write-Host "  - Python이 없어 faster-whisper 설치를 건너뜁니다." -ForegroundColor Yellow
        $script:missingTools += [pscustomobject]@{ name = "faster-whisper (Python 설치 후 install.bat 다시 실행)"; url = "" }
    }
}

# ---- 3. UXP 플러그인 설치 (A안: .ccx + UPIA / B안: 폴더+개발자모드) --
$pluginInstalled = $false
if ($SkipPlugin) {
    Write-Host "[3/5] 플러그인 설치 건너뜀 (-SkipPlugin)"
} else {
    Write-Host "[3/5] UXP 플러그인 설치 중..."

    $upiaSubPath = "Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe"
    $upiaCandidates = @()
    if ($env:CommonProgramFiles) { $upiaCandidates += (Join-Path $env:CommonProgramFiles $upiaSubPath) }
    $cpf86 = ${env:CommonProgramFiles(x86)}
    if ($cpf86) { $upiaCandidates += (Join-Path $cpf86 $upiaSubPath) }
    $upia = $upiaCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

    if ($upia) {
        try {
            # manifest.json의 version이 매번 똑같으면(예: 항상 1.0.0), Adobe 설치기가
            # "이미 같은 버전 설치돼 있음"으로 보고 실제 파일을 안 바꾸고 넘어가는
            # 경우가 있었다 - 업데이트가 하나도 적용 안 되고 계속 맨 처음 버전이
            # 돌아가는 원인이었음. 그래서 설치할 때마다 버전을 현재 시각 기준으로
            # 자동으로 바꿔서, 매번 "새 버전"으로 보이게 만든다.
            # 주의: 유닉스 타임스탬프처럼 자릿수 큰 숫자를 그대로 버전에 넣으면
            # UXP Developer Tool에서 "Expected a version for the plugin" 오류가
            # 나서 로드 자체가 실패했었다 - 그래서 각 자리를 작은 숫자로 유지한다.
            $manifestPath = Join-Path $dstPlugin "manifest.json"
            $manifestRaw = Get-Content -LiteralPath $manifestPath -Raw
            $epoch2026 = Get-Date -Year 2026 -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0
            $daysSinceEpoch = [int]((Get-Date) - $epoch2026).TotalDays
            $minutesToday = [int]((Get-Date) - (Get-Date).Date).TotalMinutes
            $uniqueVersion = "1.$daysSinceEpoch.$minutesToday"
            $manifestRaw = $manifestRaw -replace '"version"\s*:\s*"[^"]*"', ('"version": "' + $uniqueVersion + '"')
            # BOM 없는 UTF-8로 저장 - manifest.json은 순수 JSON이라 BOM이 붙으면
            # Adobe 쪽 파서가 깐깐하게 거부할 수 있어서 Set-Content -Encoding UTF8
            # (BOM 붙음) 대신 이 방식을 쓴다.
            [System.IO.File]::WriteAllText($manifestPath, $manifestRaw, (New-Object System.Text.UTF8Encoding($false)))

            $zipPath = Join-Path $env:TEMP "AutoCaption_premierepro.zip"
            $ccxPath = Join-Path $env:TEMP "AutoCaption_premierepro.ccx"
            if (Test-Path -LiteralPath $zipPath) { Remove-Item -Force -LiteralPath $zipPath }
            if (Test-Path -LiteralPath $ccxPath) { Remove-Item -Force -LiteralPath $ccxPath }
            Compress-Archive -Path (Join-Path $dstPlugin "*") -DestinationPath $zipPath -Force
            Rename-Item -LiteralPath $zipPath -NewName (Split-Path $ccxPath -Leaf)

            # v1.1.0에서 플러그인 ID가 com.yourname.autocaptionuxp -> com.haru.autocaption으로 바뀌었다.
            # 예전 ID가 등록돼 있으면 먼저 지운다 - 안 그러면 AutoCaption 패널이 두 개 보인다.
            # (UPIA의 /remove는 ID가 아니라 이름으로 지우는데, 새 ID를 설치하기 "전"이라 예전 것만 지워진다)
            $pluginsInfo = Join-Path $env:APPDATA "Adobe\UXP\PluginsInfo\v1\premierepro.json"
            # 예전 ID가 버전별로 여러 개 등록돼 있을 수 있어서(시험 PC에서 2개), 없어질 때까지 반복한다.
            # 새 ID가 이미 등록돼 있으면 이름("AutoCaption")이 같아 새 것이 지워질 수 있으므로 자동 제거하지 않는다.
            $readInfo = { if (Test-Path -LiteralPath $pluginsInfo) { Get-Content -LiteralPath $pluginsInfo -Raw } else { "" } }
            for ($i = 0; $i -lt 5 -and ((& $readInfo) -match 'com\.yourname\.autocaptionuxp'); $i++) {
                if ((& $readInfo) -match 'com\.haru\.autocaption') {
                    Write-Host "  ! 예전 AutoCaption이 남아 있습니다. Creative Cloud 앱 > 플러그인 관리에서 버전이 1.299/1.309.976 같은 예전 항목을 직접 제거해 주세요." -ForegroundColor Yellow
                    break
                }
                Write-Host "  - 예전 버전(이전 플러그인 ID) 제거 중... ($($i + 1))"
                $rm = Start-Process -FilePath $upia -ArgumentList @("/remove", "`"AutoCaption`"") -Wait -PassThru -WindowStyle Hidden
                Write-Host "    (제거 종료 코드 $($rm.ExitCode))"
            }

            $proc = Start-Process -FilePath $upia -ArgumentList @("/install", "`"$ccxPath`"") -Wait -PassThru -WindowStyle Hidden
            if ($proc.ExitCode -eq 0) {
                $pluginInstalled = $true
                Set-Content -LiteralPath (Join-Path $DestRoot "install-method.txt") -Value "ccx" -Encoding ASCII
                Write-Host "  - .ccx 패키지로 자동 설치 완료" -ForegroundColor Green
            } else {
                Write-Host "  - UPIA 설치 실패 (종료 코드 $($proc.ExitCode)) - 수동 설치로 전환합니다" -ForegroundColor Yellow
            }
        } catch {
            Write-Host "  - .ccx 자동 설치 중 오류 발생 - 수동 설치로 전환합니다: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    } else {
        Write-Host "  - UPIA(Creative Cloud 구성요소)를 찾지 못해 수동 설치로 전환합니다" -ForegroundColor Yellow
    }

    if (-not $pluginInstalled) {
        # B안: 개발자 모드 설정 + 폴더는 이미 복사됨. 마지막 "Add Plugin" 클릭만 사람이 해야 함.
        Set-Content -LiteralPath (Join-Path $DestRoot "install-method.txt") -Value "manual" -Encoding ASCII
        try {
            $devDir = Join-Path $env:CommonProgramFiles "Adobe\UXP\Developer"
            New-Item -ItemType Directory -Force -Path $devDir -ErrorAction Stop | Out-Null
            Set-Content -LiteralPath (Join-Path $devDir "settings.json") -Value '{ "developer": true }' -Encoding UTF8 -ErrorAction Stop
            Write-Host "  - UXP 개발자 모드 자동 설정 완료" -ForegroundColor Green
        } catch {
            Write-Host "  - UXP 개발자 모드는 관리자 권한이 필요합니다." -ForegroundColor Yellow
            Write-Host "    install.bat을 '관리자 권한으로 실행'해서 다시 돌려주세요 (또는 설치안내.txt의 수동 설정 참고)." -ForegroundColor Yellow
        }
        Write-Host "  - 플러그인 폴더까지는 준비됐지만, 마지막 한 단계는 직접 해야 합니다." -ForegroundColor Yellow
        Write-Host "    (설치안내.txt의 '수동으로 플러그인 추가하기' 참고, 경로: $dstPlugin\manifest.json)" -ForegroundColor Yellow
    }
}

# ---- 4. 서버 로그인 시 자동 실행 -------------------------------
if ($SkipAutoStart) {
    Write-Host "[4/5] 로그인 시 자동 실행 설정 건너뜀 (-SkipAutoStart)"
} else {
    Write-Host "[4/5] 서버 자동 실행 설정 중..."
    # v1.1.1부터 VBScript(run-server-hidden.vbs + wscript)를 쓰지 않는다. Windows가 VBScript를
    # 단계적으로 없애는 중이라, VBScript가 없는 PC(Windows 샌드박스로 확인)에서는
    # "파일 확장자 .vbs에 해당하는 스크립트 엔진이 없습니다" 창이 뜨고 서버가 아예 안 켜졌다.
    # 대신 PowerShell 스크립트(start-server-hidden.ps1)가 node를 숨김 창으로 띄운다.
    $launcher = Join-Path $dstServer "start-server-hidden.ps1"
    $psExe = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    $runCmd = "`"$psExe`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$launcher`""

    # 예전 방식의 자동 실행 흔적 정리 (안 지우면 VBScript 없는 PC에서 로그인할 때마다 오류 창이 뜬다)
    $startupDir = [Environment]::GetFolderPath("Startup")
    Remove-Item -Force -ErrorAction SilentlyContinue -LiteralPath (Join-Path $startupDir "AutoCaption-server.vbs")
    $prevEap = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    & schtasks /delete /tn "AutoCaption Server" /f 2>&1 | Out-Null
    $ErrorActionPreference = $prevEap

    # 로그인 시 자동 실행: 사용자 레지스트리의 Run 항목 (관리자 권한 불필요, VBScript 불필요)
    try {
        $runKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
        if (-not (Test-Path $runKey)) { New-Item -Path $runKey -Force | Out-Null }
        Set-ItemProperty -Path $runKey -Name "AutoCaption Server" -Value $runCmd
        Write-Host "  - 로그인 시 자동 실행 등록 완료" -ForegroundColor Green
    } catch {
        Write-Host "  - 로그인 시 자동 실행 등록 실패 - PC를 켤 때마다 server 폴더의 start-server.bat을 직접 실행해주세요" -ForegroundColor Yellow
    }

    try {
        Start-Process -FilePath $psExe -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", "`"$launcher`"") -WindowStyle Hidden
        Write-Host "  - 서버를 지금 바로 실행했습니다 (창은 안 보이는 게 정상입니다)" -ForegroundColor Green
    } catch {
        Write-Host "  - 서버 실행 실패 - server 폴더의 start-server.bat을 직접 더블클릭해주세요" -ForegroundColor Yellow
    }
}

# ---- 5. 완료 -----------------------------------------------
Write-Host ""
Write-Host "[5/5] 서버가 실제로 켜졌는지 확인 중... (최대 40초)"
$serverOk = $false
if (-not $SkipAutoStart) {
    $deadline = (Get-Date).AddSeconds(40)
    while ((Get-Date) -lt $deadline) {
        try {
            $null = Invoke-RestMethod -Uri "http://127.0.0.1:8934/ping" -TimeoutSec 2
            $serverOk = $true
            break
        } catch { Start-Sleep -Seconds 2 }
    }
    if ($serverOk) { Write-Host "  - 서버 응답 확인" -ForegroundColor Green }
    else { Write-Host "  - 서버가 응답하지 않습니다" -ForegroundColor Red }
}
Write-Host ""

# 예전에는 필요한 프로그램이 없어도 마지막에 "설치 완료!"가 떠서, 사용자는 끝난 줄 알고
# 패널을 열었다가 "서버 연결 중"에서 멈췄다 (Windows 샌드박스 시험으로 확인).
# 하나라도 빠졌거나 서버가 안 켜지면 빨간 화면으로 무엇을 해야 하는지 알려준다.
if ($script:missingTools.Count -gt 0 -or (-not $SkipAutoStart -and -not $serverOk)) {
    Write-Host "===============================================================" -ForegroundColor Red
    Write-Host "  설치가 끝나지 않았습니다 - 아직 AutoCaption을 쓸 수 없어요" -ForegroundColor Red
    Write-Host "===============================================================" -ForegroundColor Red
    if ($script:missingTools.Count -gt 0) {
        Write-Host "아래 프로그램을 먼저 설치해야 합니다:"
        foreach ($t in $script:missingTools) {
            if ($t.url) { Write-Host ("  * {0}  ->  {1}" -f $t.name, $t.url) } else { Write-Host ("  * {0}" -f $t.name) }
        }
        Write-Host ""
        Write-Host "내려받기 페이지를 지금 열어 드릴게요. 설치가 끝나면 PC를 다시 시작하고"
        Write-Host "install.bat을 한 번 더 실행해 주세요."
        Write-Host "(Python을 설치할 때는 첫 화면의 'Add python.exe to PATH'를 꼭 체크하세요.)" -ForegroundColor Yellow
        foreach ($t in $script:missingTools) { if ($t.url) { try { Start-Process $t.url } catch { } } }
    } else {
        Write-Host "필요한 프로그램은 모두 있지만 서버가 켜지지 않았습니다."
        Write-Host "PC를 다시 시작한 뒤 install.bat을 한 번 더 실행해 주세요."
        Write-Host "그래도 안 되면 $dstServer\start-server.bat을 더블클릭해서 나오는 창을 캡처해 보내주세요."
    }
    Write-Host ""
    exit 2
}

Write-Host "=== 설치 완료! ===" -ForegroundColor Cyan
Write-Host "1) Premiere Pro를 완전히 종료했다가 다시 실행하세요."
if ($pluginInstalled) {
    Write-Host "2) 상단 메뉴: Window > UXP Plugins > AutoCaption"
} else {
    Write-Host "2) 플러그인 마지막 설치 단계가 남았습니다 - 설치안내.txt의 '수동으로 플러그인 추가하기'를 따라해주세요." -ForegroundColor Yellow
}
Write-Host "3) API 키 없이도 자막 만들기는 바로 됩니다."
Write-Host "4) AI 교정·번역을 쓰려면 패널의 'Claude API 키' 입력창에 본인 Anthropic API 키를 넣어주세요."
Write-Host ""
