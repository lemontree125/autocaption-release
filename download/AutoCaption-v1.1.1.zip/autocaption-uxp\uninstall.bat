@echo off
setlocal
echo AutoCaption uninstaller - starting PowerShell...
if not exist "%~dp0uninstall.ps1" (
  echo.
  echo [ERROR] uninstall.ps1 not found next to uninstall.bat.
  echo.
  pause
  exit /b 1
)
chcp 65001 >nul
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell.exe"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1"
echo.
pause
