﻿# ============================================================
#  AutoCaption - Premiere Pro 자동 자막 플러그인 설치
#  실행: install.bat 더블클릭 (또는 이 파일을 PowerShell로 실행)
#  검증용: powershell -File install.ps1 -SkipTools -SkipPlugin
# ============================================================
param(
    [string]$DestRoot = (Join-Path $env:LOCALAPPDATA "AutoCaption"),
    [switch]$SkipTools,
    [switch]$SkipPlugin,
    [switch]$SkipAutoStart
)
$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=== AutoCaption 설치 시작 ===" -ForegroundColor Cyan
Write-Host ""

# ---- 0. 원본 폴더 확인 ----------------------------------------
$here = $PSScriptRoot
if (-not $here) { $here = Split-Path -Parent $MyInvocation.MyCommand.Path }
$srcServer = Join-Path $here "server"
$srcPlugin = Join-Path $here "plugin"
if (-not (Test-Path -LiteralPath $srcServer) -or -not (Test-Path -LiteralPath $srcPlugin)) {
    Write-Host "오류: install.bat 옆에 server, plugin 폴더가 없습니다." -ForegroundColor Red
    Write-Host "압축을 통째로 풀지 않았다면, 먼저 압축을 전부 풀고 다시 실행하세요."
    exit 1
}

# ---- 1. 서버/플러그인 파일 복사 --------------------------------
New-Item -ItemType Directory -Force $DestRoot | Out-Null

function Test-Junction($p) {
    $item = Get-Item -Force -LiteralPath $p
    return [bool]($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint)
}

$dstServer = Join-Path $DestRoot "server"
$dstPlugin = Join-Path $DestRoot "plugin"
# 재설치/업데이트일 때, 이전에 켜둔 서버가 파일을 잠그고 있으면 삭제가 막힌다.
# node.exe만 죽이면 안 된다 - run-server-hidden.vbs가 띄운 wscript.exe와,
# 그 wscript가 실행한 start-server.bat을 돌리는 cmd.exe가 그 폴더를
# "현재 작업 폴더"로 잡고 있어서, node.exe를 꺼도 cmd.exe가 폴더 자체를
# 계속 잠그고 있는 경우가 있었다 (Remove-Item이 계속 실패하던 원인).
# 그래서 node.exe/cmd.exe/wscript.exe 중 커맨드라인에 AutoCaption 서버
# 관련 흔적이 있는 건 전부 찾아서 끈다.
function Stop-AutoCaptionServerProcesses {
    try {
        $procs = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object {
                ($_.Name -eq "node.exe" -or $_.Name -eq "cmd.exe" -or $_.Name -eq "wscript.exe") -and
                $_.CommandLine -and
                ($_.CommandLine -like "*AutoCaption*server.js*" -or
                 $_.CommandLine -like "*AutoCaption*start-server.bat*" -or
                 $_.CommandLine -like "*run-server-hidden.vbs*")
            }
        foreach ($p in $procs) {
            Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
        }
        return $procs.Count
    } catch {
        return 0
    }
}

$killed = Stop-AutoCaptionServerProcesses
if ($killed -gt 0) {
    Write-Host "  - 실행 중이던 이전 서버를 종료했습니다 ($killed 개 프로세스)" -ForegroundColor DarkGray
    Start-Sleep -Milliseconds 800
}

foreach ($pair in @(@{src=$srcServer; dst=$dstServer}, @{src=$srcPlugin; dst=$dstPlugin})) {
    if (Test-Path -LiteralPath $pair.dst) {
        if (Test-Junction $pair.dst) {
            Write-Host "오류: $($pair.dst) 는 개발용 정션입니다. 보호를 위해 중단합니다." -ForegroundColor Red
            exit 1
        }
        try {
            Remove-Item -Recurse -Force -LiteralPath $pair.dst -ErrorAction Stop
        } catch {
            Write-Host "  - $($pair.dst) 삭제 실패, 서버 종료를 한 번 더 시도합니다..." -ForegroundColor Yellow
            Stop-AutoCaptionServerProcesses | Out-Null
            Start-Sleep -Seconds 1
            try {
                Remove-Item -Recurse -Force -LiteralPath $pair.dst -ErrorAction Stop
            } catch {
                # 그래도 안 되면 1초 더 기다렸다가 마지막으로 한 번 더 (핸들 해제 지연 대비)
                Stop-AutoCaptionServerProcesses | Out-Null
                Start-Sleep -Seconds 2
                try {
                    Remove-Item -Recurse -Force -LiteralPath $pair.dst -ErrorAction Stop
                } catch {
                    Write-Host "오류: $($pair.dst) 를 지울 수 없습니다." -ForegroundColor Red
                    Write-Host "작업 관리자에서 node.exe / cmd.exe / wscript.exe를 찾아 직접 끝내고 install.bat을 다시 실행해주세요." -ForegroundColor Red
                    exit 1
                }
            }
        }
    }
    Copy-Item -Recurse -LiteralPath $pair.src -Destination $pair.dst
}
if (-not (Test-Path -LiteralPath (Join-Path $dstServer "server.js"))) {
    Write-Host "오류: 설치 검증 실패 - $dstServer 에 파일이 복사되지 않았습니다 (백신이 막았는지 확인)." -ForegroundColor Red
    exit 1
}
Write-Host "[1/5] 서버/플러그인 파일 복사 완료 -> $DestRoot" -ForegroundColor Green

# ---- 2. 필수 구성요소 (Node.js / Python / ffmpeg) --------------
if ($SkipTools) {
    Write-Host "[2/5] 구성요소 설치 건너뜀 (-SkipTools)"
} else {
    Write-Host "[2/5] 필수 구성요소 확인 중... (처음이면 몇 분 걸릴 수 있어요)"
    $hasWinget = $null -ne (Get-Command winget -ErrorAction SilentlyContinue)
    $script:missing = 0

    function Ensure-Tool($cmd, $wingetId, $name) {
        if (Get-Command $cmd -ErrorAction SilentlyContinue) {
            Write-Host "  - ${name}: 이미 설치됨" -ForegroundColor Green
            return
        }
        $links = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links\$cmd.exe"
        if (Test-Path -LiteralPath $links) {
            Write-Host "  - ${name}: 이미 설치됨" -ForegroundColor Green
            return
        }
        if (-not $hasWinget) {
            Write-Host "  - ${name}: 없음 (winget이 없어 자동 설치 불가)" -ForegroundColor Yellow
            $script:missing++
            return
        }
        Write-Host "  - ${name} 설치 중..."
        try {
            winget install --id $wingetId -e --accept-source-agreements --accept-package-agreements --silent | Out-Null
            Write-Host "  - ${name}: 설치 완료" -ForegroundColor Green
        } catch {
            Write-Host "  - ${name}: 설치 실패 - 수동 설치가 필요합니다 (winget install $wingetId)" -ForegroundColor Yellow
            $script:missing++
        }
    }

    Ensure-Tool "node"   "OpenJS.NodeJS.LTS" "Node.js (로컬 서버 실행)"
    Ensure-Tool "ffmpeg" "Gyan.FFmpeg"       "ffmpeg (오디오/영상 처리)"
    Ensure-Tool "python" "Python.Python.3.12" "Python (Whisper 음성 인식)"

    if ($script:missing -gt 0) {
        Write-Host ""
        Write-Host "※ 일부 구성요소를 자동으로 설치하지 못했습니다. 설치안내.txt를 참고해 직접 설치해주세요." -ForegroundColor Yellow
    }

    # PATH 갱신 반영 (winget 설치 직후 현재 세션에는 PATH가 비어있을 수 있음)
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")

    if (Get-Command pip -ErrorAction SilentlyContinue) {
        Write-Host "  - faster-whisper(pip) 설치 중... (처음엔 몇 분 걸릴 수 있어요)"
        try {
            python -m pip install --upgrade pip --quiet 2>$null
            python -m pip install faster-whisper --quiet
            Write-Host "  - faster-whisper: 설치 완료" -ForegroundColor Green
        } catch {
            Write-Host "  - faster-whisper: 설치 실패 - cmd에서 'pip install faster-whisper'를 직접 실행해주세요." -ForegroundColor Yellow
        }
        try {
            python "$dstServer\pipeline\patch_av_compat.py" 2>$null
        } catch { }
    } else {
        Write-Host "  - pip을 찾을 수 없어 faster-whisper 설치를 건너뜁니다. Python 설치 후 다시 실행해주세요." -ForegroundColor Yellow
    }
}

# ---- 3. UXP 플러그인 설치 (A안: .ccx + UPIA / B안: 폴더+개발자모드) --
$pluginInstalled = $false
if ($SkipPlugin) {
    Write-Host "[3/5] 플러그인 설치 건너뜀 (-SkipPlugin)"
} else {
    Write-Host "[3/5] UXP 플러그인 설치 중..."

    $upiaSubPath = "Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe"
    $upiaCandidates = @()
    if ($env:CommonProgramFiles) { $upiaCandidates += (Join-Path $env:CommonProgramFiles $upiaSubPath) }
    $cpf86 = ${env:CommonProgramFiles(x86)}
    if ($cpf86) { $upiaCandidates += (Join-Path $cpf86 $upiaSubPath) }
    $upia = $upiaCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

    if ($upia) {
        try {
            # manifest.json의 version이 매번 똑같으면(예: 항상 1.0.0), Adobe 설치기가
            # "이미 같은 버전 설치돼 있음"으로 보고 실제 파일을 안 바꾸고 넘어가는
            # 경우가 있었다 - 업데이트가 하나도 적용 안 되고 계속 맨 처음 버전이
            # 돌아가는 원인이었음. 그래서 설치할 때마다 버전을 현재 시각 기준으로
            # 자동으로 바꿔서, 매번 "새 버전"으로 보이게 만든다.
            # 주의: 유닉스 타임스탬프처럼 자릿수 큰 숫자를 그대로 버전에 넣으면
            # UXP Developer Tool에서 "Expected a version for the plugin" 오류가
            # 나서 로드 자체가 실패했었다 - 그래서 각 자리를 작은 숫자로 유지한다.
            $manifestPath = Join-Path $dstPlugin "manifest.json"
            $manifestRaw = Get-Content -LiteralPath $manifestPath -Raw
            $epoch2026 = Get-Date -Year 2026 -Month 1 -Day 1 -Hour 0 -Minute 0 -Second 0
            $daysSinceEpoch = [int]((Get-Date) - $epoch2026).TotalDays
            $minutesToday = [int]((Get-Date) - (Get-Date).Date).TotalMinutes
            $uniqueVersion = "1.$daysSinceEpoch.$minutesToday"
            $manifestRaw = $manifestRaw -replace '"version"\s*:\s*"[^"]*"', ('"version": "' + $uniqueVersion + '"')
            # BOM 없는 UTF-8로 저장 - manifest.json은 순수 JSON이라 BOM이 붙으면
            # Adobe 쪽 파서가 깐깐하게 거부할 수 있어서 Set-Content -Encoding UTF8
            # (BOM 붙음) 대신 이 방식을 쓴다.
            [System.IO.File]::WriteAllText($manifestPath, $manifestRaw, (New-Object System.Text.UTF8Encoding($false)))

            $zipPath = Join-Path $env:TEMP "AutoCaption_premierepro.zip"
            $ccxPath = Join-Path $env:TEMP "AutoCaption_premierepro.ccx"
            if (Test-Path -LiteralPath $zipPath) { Remove-Item -Force -LiteralPath $zipPath }
            if (Test-Path -LiteralPath $ccxPath) { Remove-Item -Force -LiteralPath $ccxPath }
            Compress-Archive -Path (Join-Path $dstPlugin "*") -DestinationPath $zipPath -Force
            Rename-Item -LiteralPath $zipPath -NewName (Split-Path $ccxPath -Leaf)

            # v1.1.0에서 플러그인 ID가 com.yourname.autocaptionuxp -> com.haru.autocaption으로 바뀌었다.
            # 예전 ID가 등록돼 있으면 먼저 지운다 - 안 그러면 AutoCaption 패널이 두 개 보인다.
            # (UPIA의 /remove는 ID가 아니라 이름으로 지우는데, 새 ID를 설치하기 "전"이라 예전 것만 지워진다)
            $pluginsInfo = Join-Path $env:APPDATA "Adobe\UXP\PluginsInfo\v1\premierepro.json"
            if ((Test-Path -LiteralPath $pluginsInfo) -and ((Get-Content -LiteralPath $pluginsInfo -Raw) -match 'com\.yourname\.autocaptionuxp')) {
                Write-Host "  - 예전 버전(이전 플러그인 ID) 제거 중..."
                $rm = Start-Process -FilePath $upia -ArgumentList @("/remove", "`"AutoCaption`"") -Wait -PassThru -WindowStyle Hidden
                Write-Host "    (제거 종료 코드 $($rm.ExitCode))"
            }

            $proc = Start-Process -FilePath $upia -ArgumentList @("/install", "`"$ccxPath`"") -Wait -PassThru -WindowStyle Hidden
            if ($proc.ExitCode -eq 0) {
                $pluginInstalled = $true
                Set-Content -LiteralPath (Join-Path $DestRoot "install-method.txt") -Value "ccx" -Encoding ASCII
                Write-Host "  - .ccx 패키지로 자동 설치 완료" -ForegroundColor Green
            } else {
                Write-Host "  - UPIA 설치 실패 (종료 코드 $($proc.ExitCode)) - 수동 설치로 전환합니다" -ForegroundColor Yellow
            }
        } catch {
            Write-Host "  - .ccx 자동 설치 중 오류 발생 - 수동 설치로 전환합니다: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    } else {
        Write-Host "  - UPIA(Creative Cloud 구성요소)를 찾지 못해 수동 설치로 전환합니다" -ForegroundColor Yellow
    }

    if (-not $pluginInstalled) {
        # B안: 개발자 모드 설정 + 폴더는 이미 복사됨. 마지막 "Add Plugin" 클릭만 사람이 해야 함.
        Set-Content -LiteralPath (Join-Path $DestRoot "install-method.txt") -Value "manual" -Encoding ASCII
        try {
            $devDir = Join-Path $env:CommonProgramFiles "Adobe\UXP\Developer"
            New-Item -ItemType Directory -Force -Path $devDir -ErrorAction Stop | Out-Null
            Set-Content -LiteralPath (Join-Path $devDir "settings.json") -Value '{ "developer": true }' -Encoding UTF8 -ErrorAction Stop
            Write-Host "  - UXP 개발자 모드 자동 설정 완료" -ForegroundColor Green
        } catch {
            Write-Host "  - UXP 개발자 모드는 관리자 권한이 필요합니다." -ForegroundColor Yellow
            Write-Host "    install.bat을 '관리자 권한으로 실행'해서 다시 돌려주세요 (또는 설치안내.txt의 수동 설정 참고)." -ForegroundColor Yellow
        }
        Write-Host "  - 플러그인 폴더까지는 준비됐지만, 마지막 한 단계는 직접 해야 합니다." -ForegroundColor Yellow
        Write-Host "    (설치안내.txt의 '수동으로 플러그인 추가하기' 참고, 경로: $dstPlugin\manifest.json)" -ForegroundColor Yellow
    }
}

# ---- 4. 서버 로그인 시 자동 실행 -------------------------------
if ($SkipAutoStart) {
    Write-Host "[4/5] 로그인 시 자동 실행 설정 건너뜀 (-SkipAutoStart)"
} else {
    Write-Host "[4/5] 서버 자동 실행 설정 중..."
    $batPath = Join-Path $dstServer "start-server.bat"
    $vbsPath = Join-Path $dstServer "run-server-hidden.vbs"

    # 한 줄짜리 문자열로 직접 CRLF를 넣어 만든다 (Set-Content에 배열을 넘기면
    # PowerShell 버전/인코딩 조합에 따라 줄바꿈이 깨져서 cscript가
    # "종결되지 않은 문자열 상수" 오류를 내는 경우가 있었음 - 배열 대신
    # 완성된 한 문자열을 -NoNewline으로 그대로 쓰는 쪽이 안전하다).
    # 인코딩은 VBScript의 전통적인 기본값인 시스템 ANSI 코드페이지(Default)로
    # 저장한다 - 사용자 계정 이름에 한글이 섞여 있어도 같은 코드페이지로
    # 쓰고 읽으니 깨지지 않는다 (UTF-16/BOM보다 cscript 호환성이 더 확실함).
    $vbsContent =
        'Set WshShell = CreateObject("WScript.Shell")' + "`r`n" +
        'WshShell.CurrentDirectory = "' + $dstServer + '"' + "`r`n" +
        'WshShell.Run """' + $batPath + '""", 0, False' + "`r`n"
    Set-Content -LiteralPath $vbsPath -Value $vbsContent -Encoding Default -NoNewline

    # 로그인 시 자동 실행: 작업 스케줄러(schtasks)는 환경에 따라
    # "액세스가 거부되었습니다" 오류가 나는 경우가 있어서, 그보다 훨씬
    # 안전한 "시작프로그램(Startup) 폴더"에 같은 vbs를 복사해두는 방식을
    # 기본으로 쓴다 - 이쪽은 관리자 권한이 전혀 필요 없다.
    try {
        $startupDir = [Environment]::GetFolderPath("Startup")
        Copy-Item -LiteralPath $vbsPath -Destination (Join-Path $startupDir "AutoCaption-server.vbs") -Force
        Write-Host "  - 로그인 시 자동 실행 등록 완료 (시작프로그램 폴더)" -ForegroundColor Green
    } catch {
        Write-Host "  - 시작프로그램 등록 실패 - 작업 스케줄러 방식으로 다시 시도합니다" -ForegroundColor Yellow
        try {
            schtasks /create /tn "AutoCaption Server" /tr "wscript.exe `"$vbsPath`"" /sc onlogon /rl limited /f | Out-Null
            Write-Host "  - 로그인 시 자동 실행 등록 완료 (작업 스케줄러)" -ForegroundColor Green
        } catch {
            Write-Host "  - 로그인 시 자동 실행 등록 실패 - server 폴더의 start-server.bat을 직접 실행해주세요" -ForegroundColor Yellow
        }
    }

    try {
        Start-Process -FilePath "wscript.exe" -ArgumentList "`"$vbsPath`""
        Write-Host "  - 서버를 지금 바로 실행했습니다 (창은 안 보이는 게 정상입니다)" -ForegroundColor Green
    } catch {
        Write-Host "  - 서버 실행 실패 - server 폴더의 start-server.bat을 직접 더블클릭해주세요" -ForegroundColor Yellow
    }
}

# ---- 5. 완료 -----------------------------------------------
Write-Host ""
Write-Host "[5/5] 설치 작업 끝" -ForegroundColor Green
Write-Host ""
Write-Host "=== 설치 완료! ===" -ForegroundColor Cyan
Write-Host "1) Premiere Pro를 완전히 종료했다가 다시 실행하세요."
if ($pluginInstalled) {
    Write-Host "2) 상단 메뉴: Window > UXP Plugins > AutoCaption"
} else {
    Write-Host "2) 플러그인 마지막 설치 단계가 남았습니다 - 설치안내.txt의 '수동으로 플러그인 추가하기'를 따라해주세요." -ForegroundColor Yellow
}
Write-Host "3) 패널을 처음 열면 '기기 코드'가 보여요. 복사해서 관리자에게 보내고, 받은 라이선스 키를 넣으면 끝!"
Write-Host "4) 패널의 'Claude API 키' 입력창에 본인 Anthropic API 키를 넣어주세요."
Write-Host ""
