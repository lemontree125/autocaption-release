@echo off
setlocal
echo AutoCaption installer - starting PowerShell...
if not exist "%~dp0install.ps1" (
  echo.
  echo [ERROR] install.ps1 not found next to install.bat.
  echo Extract the WHOLE zip first, then run install.bat from the extracted folder.
  echo.
  pause
  exit /b 1
)
chcp 65001 >nul
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell.exe"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo ---------------------------------------------------------------
  echo [ERROR] The installer ended with exit code %RC%.
  echo If NOTHING was printed above this box ^(no "=== AutoCaption" line^),
  echo PowerShell was blocked by a security program on this PC
  echo ^(antivirus, Windows 11 Smart App Control, or a company policy^).
  echo -^> Open 설치안내.txt and follow the manual install steps.
  echo ---------------------------------------------------------------
  echo.
)
pause
