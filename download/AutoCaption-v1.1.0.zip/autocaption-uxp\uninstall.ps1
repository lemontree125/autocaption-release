﻿# ============================================================
#  AutoCaption - 제거
#  실행: uninstall.bat 더블클릭 (또는 이 파일을 PowerShell로 실행)
# ============================================================
param(
    [string]$DestRoot = (Join-Path $env:LOCALAPPDATA "AutoCaption"),
    [switch]$RemoveLicense
)
$ErrorActionPreference = "Continue"

Write-Host ""
Write-Host "=== AutoCaption 제거 시작 ===" -ForegroundColor Cyan
Write-Host ""

# ---- 1. 실행 중인 서버 종료 ------------------------------------
# node.exe뿐 아니라, run-server-hidden.vbs를 띄운 wscript.exe와 그게 돌리는
# start-server.bat의 cmd.exe도 같이 찾아서 끈다 (cmd.exe가 서버 폴더를
# 작업 폴더로 잡고 있으면 node.exe만 꺼도 폴더 삭제가 계속 막힌다).
try {
    $procs = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object {
            ($_.Name -eq "node.exe" -or $_.Name -eq "cmd.exe" -or $_.Name -eq "wscript.exe") -and
            $_.CommandLine -and
            ($_.CommandLine -like "*AutoCaption*server.js*" -or
             $_.CommandLine -like "*AutoCaption*start-server.bat*" -or
             $_.CommandLine -like "*run-server-hidden.vbs*")
        }
    foreach ($p in $procs) {
        Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
    }
    if ($procs) { Write-Host "[1/4] 실행 중이던 서버 종료 완료" -ForegroundColor Green }
    else { Write-Host "[1/4] 실행 중인 서버 없음" -ForegroundColor Green }
} catch {
    Write-Host "[1/4] 서버 종료 확인 중 오류 (무시하고 계속 진행)" -ForegroundColor Yellow
}

# ---- 2. 로그인 자동 실행 등록 제거 ------------------------------
try {
    $startupDir = [Environment]::GetFolderPath("Startup")
    $startupVbs = Join-Path $startupDir "AutoCaption-server.vbs"
    if (Test-Path -LiteralPath $startupVbs) {
        Remove-Item -Force -LiteralPath $startupVbs -ErrorAction SilentlyContinue
    }
    schtasks /delete /tn "AutoCaption Server" /f 2>$null | Out-Null
    Write-Host "[2/4] 로그인 자동 실행 등록 제거 완료" -ForegroundColor Green
} catch {
    Write-Host "[2/4] 등록된 자동 실행이 없거나 이미 제거됨" -ForegroundColor Green
}

# ---- 3. UXP 플러그인 제거 (ccx로 설치된 경우에만 자동) -----------
$methodFile = Join-Path $DestRoot "install-method.txt"
if (Test-Path -LiteralPath $methodFile) {
    $method = (Get-Content -LiteralPath $methodFile -Raw).Trim()
    if ($method -eq "ccx") {
        $upiaSubPath = "Adobe\Adobe Desktop Common\RemoteComponents\UPI\UnifiedPluginInstallerAgent\UnifiedPluginInstallerAgent.exe"
        $upiaCandidates = @()
        if ($env:CommonProgramFiles) { $upiaCandidates += (Join-Path $env:CommonProgramFiles $upiaSubPath) }
        $cpf86 = ${env:CommonProgramFiles(x86)}
        if ($cpf86) { $upiaCandidates += (Join-Path $cpf86 $upiaSubPath) }
        $upia = $upiaCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
        if ($upia) {
            try {
                Start-Process -FilePath $upia -ArgumentList @("/remove", "com.yourname.autocaptionuxp") -Wait -WindowStyle Hidden
                Write-Host "[3/4] 플러그인 제거 명령 실행 완료" -ForegroundColor Green
            } catch {
                Write-Host "[3/4] 플러그인 자동 제거 실패 - Creative Cloud Desktop의 '관리' 탭에서 AutoCaption을 직접 제거해주세요" -ForegroundColor Yellow
            }
        } else {
            Write-Host "[3/4] UPIA를 찾지 못해 자동 제거 생략 - Creative Cloud Desktop에서 직접 제거해주세요" -ForegroundColor Yellow
        }
    } else {
        Write-Host "[3/4] 수동으로 추가했던 플러그인입니다 - UXP Developer Tool에서 직접 Remove 해주세요" -ForegroundColor Yellow
    }
} else {
    Write-Host "[3/4] 설치 기록을 찾을 수 없어 플러그인 제거를 건너뜁니다" -ForegroundColor Yellow
}

# ---- 4. 복사된 파일 제거 ----------------------------------------
if (Test-Path -LiteralPath $DestRoot) {
    Remove-Item -Recurse -Force -LiteralPath $DestRoot -ErrorAction SilentlyContinue
    Write-Host "[4/4] 설치 파일 제거 완료 -> $DestRoot" -ForegroundColor Green
} else {
    Write-Host "[4/4] 제거할 설치 파일이 없음" -ForegroundColor Green
}

if ($RemoveLicense) {
    $licPath = Join-Path $env:APPDATA "AutoCaption\license.key"
    if (Test-Path -LiteralPath $licPath) {
        Remove-Item -Force -LiteralPath $licPath -ErrorAction SilentlyContinue
        Write-Host "등록된 라이선스 키도 함께 삭제했습니다" -ForegroundColor Green
    }
} else {
    Write-Host ""
    Write-Host "(등록된 라이선스 키는 남겨뒀습니다. 완전히 지우려면: uninstall.bat 대신" -ForegroundColor DarkGray
    Write-Host " powershell -File uninstall.ps1 -RemoveLicense 로 실행하세요)" -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "=== 제거 완료 ===" -ForegroundColor Cyan
Write-Host "Premiere Pro를 재시작하면 AutoCaption 패널이 목록에서 사라집니다."
Write-Host ""
